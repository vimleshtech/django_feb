from django.apps import AppConfig


class TimelineConfig(AppConfig):
    name = 'timeline'
