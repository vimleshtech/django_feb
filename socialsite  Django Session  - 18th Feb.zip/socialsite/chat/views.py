from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render_to_response 


# Create your views here.

def chatbot(request):
    return HttpResponse("chatbot section -page")

def index(request):
    #return HttpResponse("My index page")
    return render_to_response("chat/index.html")


# Create your views here.
def signup(request):
    return HttpResponse("Signup page")

def login(request):
    frm  ="<form> <p> Email : <input type='text' /> </p> <p>Password : <input type='text' /></form>"
    return HttpResponse(frm)




