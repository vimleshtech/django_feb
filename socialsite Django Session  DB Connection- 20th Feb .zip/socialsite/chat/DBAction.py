import mysql.connector


con = mysql.connector.connect(host='localhost',user='root',password='root',database='jangoex')
cur  = con.cursor()

def save_data(name,email,pwd):
    cur.execute("insert into users(name,email,pwd) values('"+name+"','"+email+"','"+pwd+"')")
    con.commit() #transaction commit / save to database 
    print('data is saved')


#save_data('Rahul','rahul@gmail.com','rahul123')
